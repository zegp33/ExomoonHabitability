from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")

fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.02,0.02,0.96,0.96])
xs1=binary.ephemeris[:,1]
ys1=binary.ephemeris[:,2]
xs2=binary.ephemeris[:,3]
ys2=binary.ephemeris[:,4]

ax.plot(xs1,ys1,'b-',label='Primary')
ax.plot(xs2,ys2,'r-',label='Secondary')
ax.plot([xs1[0]],[ys1[0]],'bo',markersize=5,markeredgecolor='none')
ax.plot([xs2[0]],[ys2[0]],'ro',markersize=5,markeredgecolor='none')

rang=1.5*binary.abin*(1+binary.ebin)
ax.set_xlim((-rang,rang))
ax.set_ylim((-rang,rang))

xt=ax.get_xticks()
dx=xt[1]-xt[0]
dy=0.1
ax.axhline(-rang+dx/3,xmin=dy,xmax=dy+dx/(2*rang),color='k')
ax.text(dy+dx/(4*rang),dx/3/(2*rang)+0.01,
"%.2f AU"%dx,horizontalalignment='center',
transform=ax.transAxes)

ax.set_title(binary.title,position=(0.5,0.95),fontsize=11)

ax.set_xticklabels([])
ax.set_yticklabels([])

saveFig('objs/binary-8d68026d8b496aafc97b7cc52169229a/binary-orbit.png',watermarkpos="inner")
