from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
ihz=loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.conf")+loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.data")

fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.1,0.1,0.8,0.8])

ts=ihz.hz[:,0]

#BHZ
ax.plot(ts,ihz.hz[:,1],'r-',linewidth=2)
#ax.plot(ts,ihz.hz[:,2],'k:',linewidth=2)
ax.plot(ts,ihz.hz[:,3],'b-',linewidth=2)
ax.fill_between(ts,ihz.hz[:,1],ihz.hz[:,3],color='g',alpha=0.3)

#SHZ
ax.plot(ts,ihz.shz[:,1],'r--',linewidth=2)
ax.plot(ts,ihz.shz[:,3],'b--',linewidth=2)
ax.fill_between(ts,ihz.hz[:,1],ihz.hz[:,3],color='g',alpha=0.3)

#CRITICAL DISTANCE
ax.axhline(binary.acrit,color='k',linewidth=2,linestyle='--',label=r'$a_{\rm crit}$')

#PLANET ORBIT
ax.axhline(planet.aorb,color='k',linewidth=2,label='Planet')

#DECORATION
ax.set_xlim((0.0,min(1.1*ihz.taums,ts[-1])))
ax.set_ylim((min(ihz.shz[:,1]),ihz.loutmax))

ax.set_xlabel(r"$\tau$ (Gyr)",fontsize=12)
ax.set_ylabel(r"$r$ (AU)",fontsize=12)
ax.set_title(binary.title,position=(0.5,1.02),fontsize=11)

#CHZ
ymin,ymax=ax.get_ylim()
rchz=0.95*(ihz.clout-ymin)/(ymax-ymin)
rihz=1.05*(ihz.clin-ymin)/(ymax-ymin)
ax.axhspan(ihz.clin,ihz.clout,color='k',alpha=0.3,linewidth=3)
ax.text(0.5,rchz,"Continuous Habitable Zone",fontsize=18,
horizontalalignment='center',verticalalignment='top',transform=ax.transAxes)
ax.text(0.05,rchz,"%.2f AU"%(ihz.clout),fontsize=10,
horizontalalignment='center',verticalalignment='top',transform=ax.transAxes)
ax.text(0.05,rihz,"%.2f AU"%(ihz.clin),fontsize=10,
horizontalalignment='center',verticalalignment='bottom',transform=ax.transAxes)
ax.grid(which="both")
ax.legend(loc='best',prop=dict(size=12))

saveFig('objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/hz-evolution.png',watermarkpos="outer")
