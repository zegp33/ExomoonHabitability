from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
ihz=loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.conf")+loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.data")

fig=plt.figure(figsize=(8,8))
axi=fig.add_axes([0.12,0.10,0.8,0.40])
axp=fig.add_axes([0.12,0.52,0.8,0.40])

insolation=ihz.insolation
fstats=ihz.fstats
pstats=ihz.pstats
ts=insolation[:,0]

#PLANET
axi.axhline(ihz.fstats[0,0]/SOLAR_CONSTANT,color='b',linestyle=':',linewidth=2,label='Average')
axp.axhline(ihz.pstats[0,0]/PPFD_EARTH,color='r',linestyle=':',linewidth=2,label='Average')

axi.plot(ts/planet.Porb,insolation[:,1]/SOLAR_CONSTANT,color='b',linestyle='-',linewidth=2,label='Instantaneous')
axp.plot(ts/planet.Porb,insolation[:,2]/PPFD_EARTH,color='r',linestyle='-',linewidth=1,label='Instantaneous')

#RANGE HZ 
axi.fill_between(ts/planet.Porb,insolation[:,5]/SOLAR_CONSTANT,insolation[:,7]/SOLAR_CONSTANT,
color='g',linestyle='-',linewidth=1,alpha=0.3)

axp.fill_between(ts/planet.Porb,insolation[:,6]/PPFD_EARTH,insolation[:,8]/PPFD_EARTH,
color='g',linestyle='-',linewidth=1,alpha=0.3)

#LABELS

axp.set_title(binary.title,position=(0.5,1.02),fontsize=11)

for ax in axi,axp:
    ax.plot([],[],"g-",linewidth=10,alpha=0.3,label="BHZ")
    ax.grid()
    ax.set_xlim((0.0,1.0))
    ax.legend(loc='best',prop=dict(size=10))

imin,imax=axi.get_ylim()
axp.set_ylim((imin,imax))

axp.set_yticks(ax.get_yticks()[1:])
axp.set_xticklabels([])

axi.set_xlabel('orbital phase',fontsize=12)
axi.set_ylabel('Insolation (PEL)',fontsize=12)
axp.set_ylabel(r'PPFD (PEL)',fontsize=12)

saveFig('objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/insolation.png',watermarkpos="outer")
