from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
from BHM.BHMastro import *

binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
ihz=loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.conf")+loadConf("objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/"+"hz.data")

fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.01,0.01,0.98,0.98])
ax.set_xticklabels([])
ax.set_yticklabels([])

bbox=dict(fc='w',ec='none')

#WIDE HZ
outwd=patches.Circle((0,0),ihz.loutwd,facecolor='g',
                     alpha=0.3,linewidth=2,zorder=-10)
ax.add_patch(outwd)
inwd=patches.Circle((0,0),ihz.linwd,facecolor='r',edgecolor='r',
                    alpha=0.2,linewidth=2,zorder=-5)
ax.add_patch(inwd)

#NARROW HZ
outnr=patches.Circle((0,0),ihz.loutnr,facecolor='g',
                     alpha=0.3,linewidth=2,zorder=-10)
ax.add_patch(outnr)

innr=patches.Circle((0,0),ihz.linnr,facecolor='r',edgecolor='r',
                    alpha=0.2,linewidth=2,zorder=-5)
ax.add_patch(innr)

#CONTINUOUS HZ
ccolor=cm.autumn(0.3)
cin=patches.Circle((0,0),ihz.clin,facecolor='none',edgecolor=ccolor,linestyle='solid',
                    alpha=1,linewidth=1,zorder=-5)
ax.add_patch(cin)

cout=patches.Circle((0,0),ihz.clout,facecolor='none',edgecolor=ccolor,linestyle='solid',
                    alpha=1,linewidth=1,zorder=-5)
ax.add_patch(cout)

#WHITE INNER AREA
inwd=patches.Circle((0,0),ihz.linwd,facecolor='w',edgecolor='g',
                    linewidth=2,zorder=-4)
ax.add_patch(inwd)

#EARTH EQUIVALENT DISTANCE
aeq=patches.Circle((0,0),ihz.leeq,facecolor='none',edgecolor=cm.gray(0.0),
                   linewidth=1,linestyle='dotted',zorder=20)
ax.add_patch(aeq)

#PLANET ORBIT
xs=planet.ephemeris[:,1]
ys=planet.ephemeris[:,2]
ax.plot(xs,ys,'k-',linewidth=2,label='Planet Orbit')
ax.plot([xs[0]],[ys[0]],'ko',markersize=5,markeredgecolor='none')

#BINARY ORBIT
xs1=binary.ephemeris[:,1]
ys1=binary.ephemeris[:,2]
xs2=binary.ephemeris[:,3]
ys2=binary.ephemeris[:,4]
ax.plot(xs1,ys1,'b-',label='Primary')
ax.plot(xs2,ys2,'r-',label='Secondary')
ax.plot([xs1[0]],[ys1[0]],'bo',markersize=5,markeredgecolor='none')
ax.plot([xs2[0]],[ys2[0]],'ro',markersize=5,markeredgecolor='none')

#CRITICAL DISTANCE
aCR=patches.Circle((0,0),binary.acrit,facecolor='none',edgecolor='k',
                   linewidth=2,linestyle='dashed',zorder=20)
ax.add_patch(aCR)

#TITLE
ax.set_title(binary.title,position=(0.5,0.95),fontsize=11)
ax.text(0.5,0.92,planet.orbit,fontsize=11,
transform=ax.transAxes,horizontalalignment='center')

#LIMITS
ax.text(0.5,0.08,r"$\tau$ =%.2f Gyr, $l_{\rm in,%s}$=%.2f AU, $l_{\rm in,%s}$=%.2f AU, $l_{\rm E,eq}$=%.2f AU, $l_{\rm out,%s}$=%.2f AU, $l_{\rm out,%s}$=%.2f AU"%(planet.tau,ihz.ini_inwd,ihz.linwd,ihz.ini_innr,ihz.linnr,ihz.leeq,ihz.ini_outnr,ihz.loutnr,ihz.ini_outwd,ihz.loutwd),transform=ax.transAxes,horizontalalignment='center',fontsize=11)
ax.text(0.5,0.04,r"$a_{\rm crit}=%.2f$ AU, $l_{\rm in,cont}=%.2f$ AU, $l_{\rm out,cont}$=%.2f AU"%(binary.acrit,ihz.clin,ihz.clout),transform=ax.transAxes,horizontalalignment='center',fontsize=11)

#RANGE
rang=1.5*max(ihz.loutwd,max(abs(xs)),max(abs(ys)))
ax.set_xlim((-rang,+rang))
ax.set_ylim((-rang,+rang))

#RESONANCES
imax=int(np.ceil(PKepler(np.sqrt(2)*rang,planet.Morb,0.0)/binary.Pbin))
for ires in xrange(2,imax):
    ares=aKepler(ires*binary.Pbin,planet.Morb,0.0)
    res=patches.Circle((0,0),ares,facecolor='none',edgecolor='k',linestyle='solid',
                       alpha=0.1,linewidth=1,zorder=-3)
    ax.add_patch(res)

#MEASURE MARK
xt=ax.get_xticks()
dx=xt[1]-xt[0]
dy=0.02
ax.axhline(-rang+dx/5,xmin=dy,xmax=dy+dx/(2*rang),color='k')
ax.text(dy+dx/(4*rang),dx/5/(2*rang)+0.01,
"%.2f AU"%dx,horizontalalignment='center',
transform=ax.transAxes)


saveFig('objs/hz-1d1dd557f5db2c8508cf283b45ab5a78/iHZ.png',watermarkpos="inner")
