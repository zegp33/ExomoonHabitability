from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
star1=loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.conf")+loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.data")
star2=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

raccel1=rot.star1_acceleration
raccel2=rot.star2_acceleration

fig=plt.figure(figsize=(8,12))
l=0.15;w=0.8;b=0.05;dh=0.02;h=(1.0-2*b-dh)/2;
ax2=fig.add_axes([l,b,w,h])
b+=h+dh
ax1=fig.add_axes([l,b,w,h])

scale=1E-21
ax1.plot(raccel1[:,0],raccel1[:,1]/scale,color='b',linestyle='--',label='Star 1 - Contraction')
ax1.plot(raccel1[:,0],raccel1[:,2]/scale,color='b',linestyle='-.',label='Star 1 - Differential Rotation')
ax1.plot(raccel1[:,0],raccel1[:,3]/scale,color='b',linestyle=':',label='Star 1 - Mass-loss')
ax1.plot(raccel1[:,0],raccel1[:,4]/scale,color='b',linestyle='-',label='Star 1 - Tides')
ax1.plot(raccel1[:,0],raccel1[:,5]/scale,color='b',linestyle='-',linewidth=5,zorder=10,alpha=0.2,label='Star 1 - Total')

ax2.plot(raccel2[:,0],raccel2[:,1]/scale,color='r',linestyle='--',label='Star 2 - Contraction')
ax2.plot(raccel2[:,0],raccel2[:,2]/scale,color='r',linestyle='-.',label='Star 2 - Differential Rotation')
ax2.plot(raccel2[:,0],raccel2[:,3]/scale,color='r',linestyle=':',label='Star 2 - Mass-loss')
ax2.plot(raccel1[:,0],raccel1[:,4]/scale,color='r',linestyle='-',label='Star 2 - Tides')
ax2.plot(raccel2[:,0],raccel2[:,5]/scale,color='r',linestyle='-',linewidth=5,zorder=10,alpha=0.2,label='Star 2 - Total')

tmax=min(star1.tau_ms,star2.tau_ms)
for ax in ax1,ax2:
    ax.set_xscale("log")
    #ax.set_yscale("log")
    ax.set_xlim((TAU_ZAMS,tmax))
    ax.set_ylabel(r"$\dot\Omega$ ($\times\,10^{-21}$)")
    ax.legend(loc='best',prop=dict(size=12))
    #ax.grid(which='both')

ax1.set_xticklabels([])
ax1.set_title(binary.title,position=(0.5,1.02),fontsize=12)
ax2.set_xlabel(r"$\tau$ (Gyr)")

saveFig('objs/rotation-a1d42408620c4b62e18c3ab3d894b454/rot-acceleration.png',watermarkpos="outer")
