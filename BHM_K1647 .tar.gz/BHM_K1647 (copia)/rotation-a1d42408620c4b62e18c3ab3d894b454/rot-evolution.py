from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
star1=loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.conf")+loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.data")
star2=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

revol1=rot.star1_binrotevol
revol2=rot.star2_binrotevol

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])

sts1=star1.rotevol[:,0]
sw1=star1.rotevol[:,1]
ts1=revol1[:,0]
w1=revol1[:,1]

sts2=star2.rotevol[:,0]
sw2=star2.rotevol[:,1]
ts2=revol2[:,0]
w2=revol2[:,1]

ax.plot(sts1,sw1/OMEGASUN,'b--',label='Star 1 (Free)')
ax.plot(ts1,w1/OMEGASUN,'b-',label='Star 1 (Tidal)')

if star2.M>0:
    ax.plot(sts2,sw2/OMEGASUN,'r--',label='Star 2 (Free)')
    ax.plot(ts2,w2/OMEGASUN,'r-',label='Star 2 (Tidal)')

ax.axhline(PSUN/DAY/binary.Psync,color='k',label=r"$P_{\rm sync}=P_{\rm bin}/%.2f$"%binary.nsync)
ax.axhline(PSUN/DAY/binary.Pbin,color='k',linestyle='--',label=r"$P_{\rm bin}$")

if binary.taumin>0:
     taumean=(binary.taumin+binary.taumax)/2
     tauerr=(binary.taumax-binary.taumin)/2

if star1.Prot>0:
     Prot=star1.Prot;
     Proterr=max(star1.Proterr,0.0);
     wmax1=PSUN/DAY/(Prot-Proterr);wmin1=PSUN/DAY/(Prot+Proterr);
     wmean1=(wmin1+wmax1)/2;werr1=(wmax1-wmin1)/2
     if binary.taumin>0:
         ax.errorbar(taumean,wmean1,xerr=tauerr,yerr=werr1,linewidth=2,color='b')
     else:
         ax.axhspan(wmin1,wmax1,color='b',alpha=0.3)

if star1.Protv>0:
     Protv=star1.Protv;
     Protverr=max(star1.Protverr,0.0);
     wmax1=PSUN/DAY/(Protv-Protverr);wmin1=PSUN/DAY/(Protv+Protverr);
     wmean1=(wmin1+wmax1)/2;werr1=(wmax1-wmin1)/2
     if binary.taumin>0:
         ax.errorbar(taumean,wmean1,xerr=tauerr,yerr=werr1,linewidth=2,color='c')
     else:
         ax.axhspan(wmin1,wmax1,color='c',alpha=0.3)

if star2.M>0 and star2.Prot>0:
     Prot=star2.Prot;
     Proterr=max(star2.Proterr,0.0);
     wmax2=PSUN/DAY/(Prot-Proterr);wmin2=PSUN/DAY/(Prot+Proterr);
     wmean2=(wmin2+wmax2)/2;werr2=(wmax2-wmin2)/2
     if binary.taumin>0:
         ax.errorbar(taumean,wmean2,xerr=tauerr,yerr=werr2,linewidth=2,color='r')
     else:
         ax.axhspan(wmin2,wmax2,color='r',alpha=0.3)

if star2.M>0 and star2.Protv>0:
     Protv=star2.Protv;
     Protverr=max(star2.Protverr,0.0);
     wmax2=PSUN/DAY/(Protv-Protverr);wmin2=PSUN/DAY/(Protv+Protverr);
     wmean2=(wmin2+wmax2)/2;werr2=(wmax2-wmin2)/2
     if binary.taumin>0:
         ax.errorbar(taumean,wmean2,xerr=tauerr,yerr=werr2,linewidth=2,color='g')
     else:
         ax.axhspan(wmin2,wmax2,color='g',alpha=0.3)

ax.set_xscale("log")
ax.set_yscale("log")

ax.set_title(binary.title,position=(0.5,1.02),fontsize=12)

ax.text(1.07,0.5,r"$P$ (days)",rotation=90,verticalalignment='center',horizontalalignment='center',transform=ax.transAxes)

#PERIODS
wmin=min(min(w1),min(sw1),min(w2),min(sw2))/OMEGASUN
wmax=max(max(w1),max(sw1),max(w2),max(sw2))/OMEGASUN

ax.set_xlim((TAU_ZAMS,12.0))
ax.set_ylim((wmin,wmax))

tmin,tmax=ax.get_xlim()
wmin,wmax=ax.get_ylim()
Pmin=2*PI/(wmax*OMEGASUN)/DAY
Pmax=2*PI/(wmin*OMEGASUN)/DAY

for P in np.logspace(np.log10(Pmin),np.log10(Pmax),10):
    #P=np.ceil(P)
    if P>Pmax:break
    w=2*PI/(P*DAY)/OMEGASUN
    ax.axhline(w,xmin=0.98,xmax=1.00,color='k')
    ax.text(tmax,w,"%.1f"%P,transform=offSet(5,0),verticalalignment='center',horizontalalignment='left',fontsize=10)

ax.set_ylabel("$\Omega/\Omega_\odot$")
ax.set_xlabel(r"$\tau$ (Gyr)")
ax.grid(which='both')
ax.legend(loc='lower left',prop=dict(size=12))

saveFig('objs/rotation-a1d42408620c4b62e18c3ab3d894b454/rot-evolution.png',watermarkpos="outer")
