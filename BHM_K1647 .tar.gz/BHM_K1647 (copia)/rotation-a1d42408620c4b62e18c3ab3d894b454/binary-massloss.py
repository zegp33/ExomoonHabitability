from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")
binary=loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.conf")+loadConf("objs/binary-8d68026d8b496aafc97b7cc52169229a/"+"binary.data")
star1=loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.conf")+loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.data")
star2=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.15,0.1,0.8,0.8])

ts1=rot.star1_binactivity[:,0]
Ml1=rot.star1_binactivity[:,7]
Ml1_func=interp1d(ts1,Ml1,kind='slinear')
sMl1=star1.activity[:,7]

ts2=rot.star2_binactivity[:,0]
Ml2=rot.star2_binactivity[:,7]
Ml2_func=interp1d(ts2,Ml2,kind='slinear')
sMl2=star2.activity[:,7]

tmin=max(min(ts1),min(ts2))*1.0001
tmax=min(max(ts1),max(ts2))*0.9999
ts=np.logspace(np.log10(tmin),np.log10(tmax),100)

ax.plot(ts1,Ml1,'b-',label='Star 1 (Tidal)')
ax.plot(ts1,sMl1,'b--',label='Star 1 (Free)')

if star2.M>0:
    ax.plot(ts2,Ml2,'r-',label='Star 2 (Tidal)')
    ax.plot(ts2,sMl2,'r--',label='Star 2 (Free)')
    ax.plot(ts,Ml1_func(ts)+Ml2_func(ts),'k-',linewidth=2,label='Total (Tidal)')

ax.set_xscale("log")
ax.set_yscale("log")

ax.set_title(binary.title,position=(0.5,1.02),fontsize=12)
ax.set_xlim((TAU_ZAMS,12.0))

ax.set_ylabel(r"$\dot M$ ($M_\odot$/yr)")
ax.set_xlabel(r"$\tau$ (Gyr)")

ax.grid(which='both')
ax.legend(loc='lower left',prop=dict(size=10))

saveFig('objs/rotation-a1d42408620c4b62e18c3ab3d894b454/binary-massloss.png',watermarkpos="outer")
