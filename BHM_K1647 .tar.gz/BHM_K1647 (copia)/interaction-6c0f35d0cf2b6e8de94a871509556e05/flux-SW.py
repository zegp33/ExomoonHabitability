from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
env=loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.conf")+loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")

#LOADING REFERENCE SOLAR SYSTEM
from BHM.BHMdata import *
fast=loadResults(DATA_DIR+"SolarSystemReference/fast/")
tsfast=fast.interaction.lumflux[:,0]
slow=loadResults(DATA_DIR+"SolarSystemReference/slow/")
tsslow=slow.interaction.lumflux[:,0]
nominal=loadResults(DATA_DIR+"SolarSystemReference/nominal/")
tsnom=nominal.interaction.lumflux[:,0]

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])

ts=env.lumflux[:,0]

#AREAS
ax.fill_between(ts,env.lumflux[:,31],env.lumflux[:,33],color='k',alpha=0.2)
ax.fill_between(ts,env.lumflux[:,19],env.lumflux[:,21],color='g',alpha=0.3)
ax.fill_between(tsnom,nominal.interaction.lumflux[:,31],
                      nominal.interaction.lumflux[:,33],color='r',alpha=0.2)
ax.plot([0],[0],color='g',alpha=0.3,linewidth=10,label='BHZ')
ax.plot([0],[0],color='k',alpha=0.3,linewidth=10,label='Single Primary HZ')
ax.plot([0],[0],color='r',alpha=0.3,linewidth=10,label='Solar System HZ')

ax.plot(ts,env.lumflux[:,23],'k-',linewidth=2,label=r'Planet $a_{\rm p}$=%.2f AU'%planet.aorb)
#ax.plot(ts,env.lumflux[:,35],'k--',linewidth=2,label='Single Primary Earth-analogue')

ax.text(4.56,1.0,r"$\oplus$",
        horizontalalignment='center',verticalalignment='center',
        fontsize=20)

ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlim((env.tauini,rot.taumaxrot))

#MASS-LOSS AXIS
xmin,xmax=ax.get_xlim()
xt=ax.get_yticks()
for x in xt:
   Ml=x*env.facN*env.dotNl
   lexp=np.floor(np.log10(Ml))
   mant=Ml/10**lexp
   ax.text(xmax,x,"$10^{%d}$"%lexp,verticalalignment='center',transform=offSet(5,0))
ax.text(1.07,0.5,r"${\dot N}$ ($\times %.2f\;{\rm ions\cdot s}^{-1}$), $R_p = %.2f\,R_\oplus$"%(mant,planet.Rp),
        rotation=90,
        horizontalalignment='left',verticalalignment='center',
        transform=ax.transAxes)

ax.set_title(env.title,position=(0.5,1.02),fontsize=12)
ax.legend(loc='lower left',prop=dict(size=10))
ax.grid(which="both",zorder=-10)

ax.set_xlabel(r"$\tau$ (Gyr)")
ax.set_ylabel(r"$F_{\rm SW}$ (PEL)")

saveFig('objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/flux-SW.png',watermarkpos="inner")
