from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
env=loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.conf")+loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")

#LOADING REFERENCE SOLAR SYSTEM
from BHM.BHMdata import *
fast=loadResults(DATA_DIR+"SolarSystemReference/fast/")
tsfast=fast.interaction.intflux[:,0]
slow=loadResults(DATA_DIR+"SolarSystemReference/slow/")
tsslow=slow.interaction.intflux[:,0]
nominal=loadResults(DATA_DIR+"SolarSystemReference/nominal/")
tsnom=nominal.interaction.intflux[:,0]

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.80,0.8])

ts=env.intflux[:,0]
for tvec in 'ts','tsnom','tsfast','tsslow':
    exec("cond=%s<env.tauref"%tvec)
    exec("%s=%s[cond]"%(tvec,tvec))

ts=env.intflux[cond,0]

#RANGES
arrs=[]
facabs=1

arrs+=[facabs*nominal.interaction.intflux[cond,23],facabs*nominal.interaction.intflux[cond,25]]
ax.fill_between(tsnom,facabs*nominal.interaction.intflux[cond,23],facabs*nominal.interaction.intflux[cond,25],color='r',alpha=0.2,label='Single Primary HZ')

arrs+=[facabs*env.intflux[cond,23],facabs*env.intflux[cond,25]]
ax.fill_between(ts,facabs*env.intflux[cond,23],facabs*env.intflux[cond,25],color='k',alpha=0.2,label='Single Primary HZ')

arrs+=[facabs*env.intflux[cond,11],facabs*env.intflux[cond,13]]
ax.fill_between(ts,facabs*env.intflux[cond,11],facabs*env.intflux[cond,13],color='g',alpha=0.3,label='BHZ')

ax.plot([0],[0],color='g',alpha=0.3,linewidth=10,label='BHZ')
ax.plot([0],[0],color='k',alpha=0.3,linewidth=10,label='Single Primary HZ')
ax.plot([0],[0],color='r',alpha=0.3,linewidth=10,label='Solar System HZ')

#PLANET
arrs+=[facabs*env.intflux[cond,15],facabs*env.intflux[cond,27]]
ax.plot(ts,facabs*env.intflux[cond,15],'k-',linewidth=2,label=r'Planet $a_{\rm p}$=%.2f AU'%planet.aorb)
#ax.plot(ts,facabs*env.intflux[cond,27],'k--',linewidth=2,label='Single Primary Earth-Analogue')

ymin,ymean,ymax=minmeanmaxArrays(arrs)
expscl=int(np.log10(ymax))
scl=10**expscl

ax.set_xscale("log")
#ax.set_xlim((env.tauini,rot.taumaxrot))
ax.set_xlim((env.tauini,env.tauref))

ax.set_yscale("log")
ylow=max(ymin,ymean/10)
ax.set_ylim((ylow,ymax))
xt=ax.get_yticks()
logTickLabels(ax,-1,3,(2,),axis="y",frm='$%.0f\times$',notation="sci",fontsize=11)
xt2=ax.get_yticks()

#MASS-LOSS AXIS
xmin,xmax=ax.get_xlim()
#MAIN TICKS
mant=1.0
for x in xt:
   if x<ylow or x>ymax:continue
   Ml=x*env.intPl*env.facP
   lexp=np.floor(np.log10(Ml))
   mant=Ml/10**lexp
   ax.text(xmax,x,"$10^{%d}$"%lexp,verticalalignment='bottom',transform=offSet(5,0))

#SECONDARY TICKS
for x in xt2:
   if x<ylow or x>ymax:continue
   Ml=x*env.intPl*env.facP
   lexp=np.floor(np.log10(Ml/mant))
   val=Ml/10**lexp/mant
   if np.abs(val-1)<1E-3:continue
   ax.text(xmax,x,r"$%.0f\times$"%(val),verticalalignment='center',transform=offSet(5,0),fontsize=10)

ax.text(1.07,0.5,r"${\Delta P}_{\rm Ent}$ [$\times %.2f\;{\rm bars}$], $R_p = %.2f\,R_\oplus$"%(mant,planet.Rp),
        rotation=90,
        horizontalalignment='left',verticalalignment='center',
        transform=ax.transAxes)

ax.set_ylim((ylow,ymax))
ax.set_title(env.title,position=(0.5,1.02),fontsize=12)
ax.grid(which="both")
ax.legend(loc='lower right',prop=dict(size=10))
ax.set_xlabel(r"$\tau$ [Gyr]")
ax.set_ylabel(r"$\Phi_{\rm SW}(\tau\,;\,\tau_{\rm ini})$ [${\rm SWPEL\cdot\,Gyr}$]")


saveFig('objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/int-SW.png',watermarkpos="inner")
