from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
env=loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.conf")+loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")

#LOADING REFERENCE SOLAR SYSTEM
from BHM.BHMdata import *
fast=loadResults(DATA_DIR+"SolarSystemReference/fast/")
tsfast=fast.interaction.lumflux[:,0]
slow=loadResults(DATA_DIR+"SolarSystemReference/slow/")
tsslow=slow.interaction.lumflux[:,0]
nominal=loadResults(DATA_DIR+"SolarSystemReference/nominal/")
tsnom=nominal.interaction.lumflux[:,0]

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])

ts=env.lumflux[:,0]

ax.plot(ts,env.lumflux[:,36],'k-',label=r"Planet, $R_p$ = %.2f $R_\oplus$"%planet.Rp)
ax.fill_between(tsnom,nominal.interaction.lumflux[:,38],
                   nominal.interaction.lumflux[:,39],color='r',alpha=0.2)
ax.fill_between(ts,env.lumflux[:,38],env.lumflux[:,39],color='k',alpha=0.2)
ax.plot([],[],'k-',linewidth=10,alpha=0.2,label='Single Primary HZ')
ax.plot([],[],'r-',linewidth=10,alpha=0.2,label='Solar System HZ')

ax.text(0.05,0.05,planet.orbit,transform=ax.transAxes)
ax.set_title(env.title,position=(0.5,1.02),fontsize=12)
ax.legend(loc='upper left',prop=dict(size=12))
ax.set_xlabel(r"$\tau$ (Gyr)")
ax.set_ylabel(r"$R_{\rm S}/R_{\rm p}$")

ax.set_xscale("log")

#ymin,ymean,ymax=minmeanmaxArrays(arrs)
#ax.set_xlim((max(ymin,ymean/10),ymax))

saveFig('objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/standoff-distance.png',watermarkpos="outer")
