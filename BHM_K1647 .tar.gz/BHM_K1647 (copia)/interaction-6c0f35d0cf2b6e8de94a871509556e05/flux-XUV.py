from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
env=loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.conf")+loadConf("objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/"+"interaction.data")
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")
rot=loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.conf")+loadConf("objs/rotation-a1d42408620c4b62e18c3ab3d894b454/"+"rotation.data")

#LOADING REFERENCE SOLAR SYSTEM
from BHM.BHMdata import *
fast=loadResults(DATA_DIR+"SolarSystemReference/fast/")
tsfast=fast.interaction.lumflux[:,0]
slow=loadResults(DATA_DIR+"SolarSystemReference/slow/")
tsslow=slow.interaction.lumflux[:,0]
nominal=loadResults(DATA_DIR+"SolarSystemReference/nominal/")
tsnom=nominal.interaction.lumflux[:,0]

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])
ax2=ax.twinx()

ts=env.lumflux[:,0]

#AREAS
ax.fill_between(tsnom,nominal.interaction.lumflux[:,15],
                   nominal.interaction.lumflux[:,16],color='r',alpha=0.2)
ax.fill_between(ts,env.lumflux[:,15],env.lumflux[:,16],color='k',alpha=0.2)
ax.fill_between(ts,env.lumflux[:,9],env.lumflux[:,10],color='g',alpha=0.3)
ax.plot([0],[0],color='g',alpha=0.3,linewidth=10,label='BHZ')
ax.plot([0],[0],color='k',alpha=0.3,linewidth=10,label='Single Primary HZ')
ax.plot([0],[0],color='r',alpha=0.3,linewidth=10,label='Solar Sytem HZ')

#PLANET
ax.plot(ts,env.lumflux[:,11],'k-',linewidth=2,label=r'Planet $a_{\rm p}$=%.2f AU'%planet.aorb)
#ax.plot(ts,env.lumflux[:,17],'k--',linewidth=2,label='Single Primary Earth Analogue')

ax.text(4.56,1.0,r"$\oplus$",
        horizontalalignment='center',verticalalignment='center',
        fontsize=20)

ax.set_xscale("log")
ax.set_xlim((env.tauini,rot.taumaxrot))

for axt in ax,ax2:
   axt.set_yscale("log")
ymin,ymax=ax.get_ylim()
ax2.set_ylim((ymin,ymax))

#MASS-LOSS AXIS
xl=[]
xt=ax2.get_yticks()
for x in xt:
   Ml=x*env.facM*env.dotM
   lexp=np.floor(np.log10(Ml))
   mant=Ml/10**lexp
   xl+=["$10^{%d}$"%lexp]
ax2.set_yticklabels(xl)
ax.text(1.07,0.5,r"${\dot M}_{\rm Photo}$ ($\times %.2f\;{\rm kg\cdot\,s}^{-1}$), $\rho_p = %.2f\;{\rm g/cm}^3$"%(mant,planet.rho/1E3),
        rotation=90,
        horizontalalignment='left',verticalalignment='center',
        transform=ax.transAxes)

ax.set_title(env.title,position=(0.5,1.02),fontsize=12)
ax.legend(loc='lower left',prop=dict(size=10))
ax.grid(which="both",zorder=-10)

ax.set_xlabel(r"$\tau$ (Gyr)")
ax.set_ylabel(r"$F_{\rm XUV}$ (PEL)")

saveFig('objs/interaction-6c0f35d0cf2b6e8de94a871509556e05/flux-XUV.png',watermarkpos="inner")
