from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")

fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.0,0.0,1.0,1.0])

RJ=11.2
color='c'

plan=patches.Circle((0.0,0.0),planet.Rp,fc=color,ec='none',zorder=-10)
core=patches.Circle((0.0,0.0),planet.Rc*planet.Rp,fc='b',alpha=0.3,ec='none',zorder=-5)
icore=patches.Circle((0.0,0.0),planet.Ric*planet.Rp,fc='r',alpha=0.3,ec='none',zorder=-5)

earth=patches.Circle((0.0,0.0),1.0,
                     linestyle='dashed',fc='none',zorder=10)
jupiter=patches.Circle((0.0,0.0),RJ,
                       linestyle='dotted',fc='none',zorder=10)

ax.add_patch(plan)
ax.add_patch(core)
ax.add_patch(icore)
ax.add_patch(earth)
ax.add_patch(jupiter)

ax.text(0.0,1.0,'Earth',fontsize=12,transform=offSet(0,5),horizontalalignment='center')
ax.text(0.0,RJ,'Jupiter',fontsize=12,transform=offSet(0,5),horizontalalignment='center')
ax.text(0.0,-planet.Rp,'%s'%planet.str_PlanetID.replace("'",""),fontsize=14,transform=offSet(0,-10),horizontalalignment='center',verticalalignment='top')

ax.set_xticks([])
ax.set_yticks([])

ax.set_title(planet.title,position=(0.5,0.05),fontsize=16)

if planet.Mg<0.05:Rscale=1.0
else:Rscale=RJ
rang=max(1.5*Rscale,1.5*planet.Rp)
ax.set_xlim((-rang,+rang))
ax.set_ylim((-rang,+rang))

saveFig('objs/planet-ef36d2f6ddb0127014a97e83db54534b/planet-schematic.png',watermarkpos="inner")
