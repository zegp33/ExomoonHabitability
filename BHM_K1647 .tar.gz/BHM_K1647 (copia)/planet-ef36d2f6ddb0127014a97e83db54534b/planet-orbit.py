from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")

fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.02,0.02,0.96,0.96])
xs=planet.ephemeris[:,1]
ys=planet.ephemeris[:,2]

ax.plot(xs,ys,'k-',label='Planet Orbit')
ax.plot([xs[0]],[ys[0]],'ko',markersize=5,markeredgecolor='none')

rang=1.2*planet.aorb*(1+planet.eorb)
ax.set_xlim((-rang,rang))
ax.set_ylim((-rang,rang))

xt=ax.get_xticks()
dx=xt[1]-xt[0]
dy=0.1
ax.axhline(-rang+dx/3,xmin=dy,xmax=dy+dx/(2*rang),color='k')
ax.text(dy+dx/(4*rang),dx/3/(2*rang)+0.01,
"%.2f AU"%dx,horizontalalignment='center',
transform=ax.transAxes)

ax.set_title(planet.title,position=(0.5,0.95),fontsize=14)
ax.text(0.5,0.92,planet.orbit,transform=ax.transAxes,horizontalalignment="center")
ax.plot([0],[0],'x')

ax.set_xticklabels([])
ax.set_yticklabels([])

saveFig('objs/planet-ef36d2f6ddb0127014a97e83db54534b/planet-orbit.png',watermarkpos="inner")
