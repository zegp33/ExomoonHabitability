from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
planet=loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.conf")+loadConf("objs/planet-ef36d2f6ddb0127014a97e83db54534b/"+"planet.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])

thermevol=planet.thermevol
ts=thermevol[:,0]

props={
r"$\langle{\cal M}_{\rm dip}\rangle/{\cal M}_{\rm Earth}$":
dict(
lstyle=dict(color='b'),
pcol=9),
r"$\langle Q\rangle$ (W)":
dict(
lstyle=dict(color='k'),
pcol=6),
r"$\langle Q_{\rm conv}\rangle$ (W)":
dict(
lstyle=dict(color='r'),
pcol=7),
r"$\langle R_{\rm ic}\rangle/R_{\rm p}$":
dict(
lstyle=dict(color='c'),
pcol=3),
r"$\langle R_{\rm c}\rangle/R_{\rm p}$":
dict(
lstyle=dict(color='r'),
pcol=2),
r"$\langle \rho_{\rm c}\rangle$ (kg m$^{-3}$)":
dict(
lstyle=dict(color='g'),
pcol=5),
r"$\langle \rho\rangle$ (kg m$^{-3}$)":
dict(
lstyle=dict(color='g'),
pcol=4),
}

for prop in props.keys():
    pdict=props[prop]
    exec("ps=thermevol[:,%d]"%(pdict["pcol"]))
    pm=ps.mean()
    if pm==0:pm=1
    st=pdict["lstyle"]
    ax.plot(ts,ps/pm,label="%s=%.2e"%(prop,pm),**st)

ax.set_yscale("log")

if 'Gas' in planet.type:
    ax.set_xscale("log")

ax.set_xlim((0.1,10.0))
ax.legend(loc='best',prop=dict(size=10))

ax.set_xlabel(r"$\tau$ (Gyr)")
ax.set_ylabel(r"Property/Mean value")

ax.grid()
ax.set_xlim((TAU_MIN,planet.tdyn))
ax.set_title(planet.title,position=(0.5,1.02),fontsize=16)

saveFig('objs/planet-ef36d2f6ddb0127014a97e83db54534b/thermal-evolution.png',watermarkpos="outer")
