from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.15,0.1,0.8,0.8])

ts=star.activity[:,0]
LXUV=star.activity[:,13]

ax.plot(ts,LXUV/(LXUVSUN/1E7))

ax.set_xscale("log")
ax.set_yscale("log")

ax.text(4.56,1.0,r"$\odot$",
        horizontalalignment='center',verticalalignment='center',
        fontsize=20)

ax.set_title(star.title,position=(0.5,1.02),fontsize=12)
ax.set_xlim((TAU_ZAMS,star.tau_ms))

ax.set_ylabel(r"$L_{\rm XUV}/L_{\rm XUV,\odot,today}$")
ax.set_xlabel(r"$\tau$ (Gyr)")

ax.grid(which='both')

saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/stellar-LXUV.png',watermarkpos="outer")
