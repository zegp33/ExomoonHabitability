from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
fig=plt.figure(figsize=(8,8))
ax=fig.add_axes([0.0,0.0,1.0,1.0])
bbox=dict(fc='w',ec='none')

star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

M=star.M
Z=star.Z
tau=star.tau
R=star.Rins
T=star.Tins

color=cm.RdYlBu((T-2000)/7000)

starc=patches.Circle((0.0,0.0),R,fc=color,ec='none')
sun=patches.Circle((0.0,0.0),1.0,
                   linestyle='dashed',fc='none',zorder=10)
ax.add_patch(starc)
ax.add_patch(sun)
ax.text(0.0,1.0,'Sun',
fontsize=12,transform=offSet(0,5),horizontalalignment='center',verticalalignment='bottom',color=cm.gray(0.5),bbox=bbox,zorder=10)
ax.text(0.0,-R,
star.str_StarID.replace("'",""),fontsize=12,transform=offSet(0,-5),horizontalalignment='center',verticalalignment='top',color=cm.gray(0.5),bbox=bbox,zorder=10)

if star.R>0:
   starobs=patches.Circle((0.0,0.0),star.R,
                          linestyle='solid',fc='none',zorder=10,color='b')
   ax.add_patch(starobs)

ax.set_xticks([])
ax.set_yticks([])

if len(star.str_StarID)>0:startitle="%s: "%star.str_StarID.replace("'","")
else:startitle=""
ax.set_title(r"%s$M = %.3f\,M_{\odot}$, $Z=$%.4f, $\tau=%.3f$ Gyr, $R = %.3f\,R_{\odot}$, $T_{\rm eff} = %.1f$ K"%(startitle,M,Z,tau,R,T),
position=(0.5,0.05),fontsize=14)

rang=max(1.5*R,1.5)
ax.set_xlim((-rang,+rang))
ax.set_ylim((-rang,+rang))

#MODEL WATERMARK
ax.text(0.5,0.95,"PARSEC:Z=0.0140,M=1.00",horizontalalignment="center",fontsize="10",color="k",alpha=0.3,transform=ax.transAxes)


saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/radius-schematic.png',watermarkpos="inner")
