from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
from BHM.BHMnum import *
star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])
bbox=dict(fc='w',ec='none')

ts,evotrack=interpMatrix(star.evotrack)
yplot=[evotrack[1](ts)/1E2/GRAVSUN,evotrack[2](ts)/TSUN,evotrack[3](ts),evotrack[4](ts)]
ax.plot(ts,evotrack[1](ts)/1E2/GRAVSUN,label=r"$g_{\rm surf}$")
ax.plot(ts,evotrack[2](ts)/TSUN,label=r"$T_{\rm eff}$")
ax.plot(ts,evotrack[3](ts),label=r"$R$")
ax.plot(ts,evotrack[4](ts),label=r"$L$")

ax.axvline(star.tau_ms,color='k',linestyle='--',label='Main Sequence')
ax.axvline(star.tau,color='k',linestyle='-',label='Stellar Age')

ax.set_xscale('log')
ax.set_yscale('log')

ax.set_title(star.title,position=(0.5,1.02),fontsize=11)
ax.set_xlabel(r"$\tau$ (Gyr)")
ax.set_ylabel(r"Property in Solar Units")

ymin,ymean,ymax=minmeanmaxArrays(yplot)
ymin=max(0.1,ymin)
ymax=min(10.0,ymax)
ax.set_xlim((star.tau_min,star.tau_max))
ax.set_ylim((ymin,ymax))
ax.grid(which="both")

#MODEL WATERMARK
ax.text(0.5,0.95,"PARSEC:Z=0.0140,M=1.00",horizontalalignment="center",fontsize="10",color="k",alpha=0.3,transform=ax.transAxes,bbox=bbox,zorder=10)

ax.legend(loc='lower left',ncol=3,prop=dict(size=10))

saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/stellar-props.png',watermarkpos="outer")
