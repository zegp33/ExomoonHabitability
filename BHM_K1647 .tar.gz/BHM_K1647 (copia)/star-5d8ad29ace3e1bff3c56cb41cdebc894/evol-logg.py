from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
from BHM.BHMnum import *
star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])
bbox=dict(fc='w',ec='none')

#EVOLUTIONARY TRACK
ts,evotrack=interpMatrix(star.evotrack)

#LIMITS
tini=0.1
tend=star.tau_ms

#TIMES
ts=ts[ts>=tini]
ts=ts[ts<=tend]

#DATA
logts=np.log10(ts)
Ts=evotrack[2](ts)
loggs=np.log10(evotrack[1](ts))

#TRAJECTORY
ax.plot(Ts,loggs,"k-")

#EXTREMES
ax.plot([Ts[0]],[loggs[0]],
"go",markersize=10,markeredgecolor='none',label=r"$t_{\rm ini}=$0.1 Gyr")

ax.plot([Ts[-1]],[loggs[-1]],
"ro",markersize=10,markeredgecolor='none',label=r"$t_{\rm end}=$%.1f Gyr"%star.tau_ms)

#PRESENT PROPERTIES
ax.plot([star.Tins],[np.log10(star.gins)],
"bo",markersize=10,markeredgecolor='none',label=r"$t=$%.1f Gyr"%star.tau)

#EVOLUTIONARY TRACK
dt=round((tend-tini)/20,1)
logts=np.log10(np.arange(tini,tend,dt))
Ts=evotrack[2](ts)
loggs=np.log10(evotrack[1](ts))
ax.plot(Ts,loggs,"ko",label='Steps of %.2f Gyr'%dt,markersize=3)
ax.text(TSUN,np.log10(GRAVSUN*1E2),r"$\odot$",fontsize=16)

if star.logg>0:ax.axhline(star.logg,color='g',label='Observed Value')
if star.T>0:ax.axvline(star.T,color='g')
if star.loggerr>0:
   ax.axhspan(star.logg-star.loggerr,star.logg+star.loggerr,color='g',alpha=0.2)
if star.Terr>0:
   ax.axvspan(star.T-star.Terr,star.T+star.Terr,color='g',alpha=0.2)

ax.set_title(star.title,position=(0.5,1.02),fontsize=12)
ax.set_xlabel(r"$T_{\rm eff}$ (K)")
ax.set_ylabel(r"$\log\,g$ [cm s$^{-2}$]")

Tmin,Tmax=ax.get_xlim()
ax.set_xlim((Tmax,Tmin))

#MODEL WATERMARK
ax.text(0.5,0.95,
"PARSEC:Z=0.0140,M=1.00",horizontalalignment="center",fontsize="10",color="k",bbox=bbox,zorder=10,alpha=0.3,transform=ax.transAxes)

ax.grid(which="both")
ax.legend(loc='upper right',prop=dict(size=10))

saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/evol-logg.png',watermarkpos="outer")
