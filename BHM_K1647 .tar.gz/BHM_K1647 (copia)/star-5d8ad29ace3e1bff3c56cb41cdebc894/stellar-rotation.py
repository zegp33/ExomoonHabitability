from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])
bbox=dict(fc='w',ec='none')

ts=star.rotevol[:,0]
wconv=star.rotevol[:,1]
wrad=star.rotevol[:,2]

ax.plot(ts,wconv/OMEGASUN,'b-',label='Convective Envelope')
if star.M>=MMIN_CONV:
    ax.plot(ts,wrad/OMEGASUN,'b--',label='Radiative Core')
ax.plot(ts,(ts/TAGE)**(-0.5),'g-',label='Skumanich Relationship')

if star.Prot>0:ax.axhline(PSUN/DAY/star.Prot,color='b')
if star.Proterr>0:
     wmax=PSUN/DAY/(star.Prot-star.Proterr);wmin=PSUN/DAY/(star.Prot+star.Proterr);
     ax.axhspan(wmin,wmax,color='b',alpha=0.3)

ax.set_xscale("log")
ax.set_yscale("log")

ax.set_title(star.title,position=(0.5,1.02),fontsize=12)

#ax.text(0.5,0.08,r"$\tau_{\rm disk}$=%.3f Gyr, $\Omega_{\rm sat}$ = %.2f $\Omega_\odot$, $K_{\rm W}$ = %.2e"%(star.taudisk,star.wsat_scaled,star.Kw),
#transform=ax.transAxes,horizontalalignment='center',bbox=bbox)

ax.set_xlim((star.tmoi_min,star.tmoi_max))

ax.text(1.07,0.5,r"$P$ (days)",rotation=90,verticalalignment='center',horizontalalignment='center',transform=ax.transAxes)

#DATA FOR OTHER STARS
for star_name in ROTAGE_STARS.keys():
    staro=ROTAGE_STARS[star_name]
    tau=staro["tau"]
    Prot=staro["Prot"]
    ax.plot([tau],[2*PI/(Prot*DAY)/OMEGASUN],'o',markersize=10,markeredgecolor='none',color=cm.gray(0.5),zorder=-10)
    ax.text(tau,2*PI/(Prot*DAY)/OMEGASUN,star_name,transform=offSet(-10,staro["up"]),horizontalalignment="right",color=cm.gray(0.1),zorder=-10,fontsize=10)

#PERIODS
tmin,tmax=ax.get_xlim()
wmin,wmax=ax.get_ylim()
Pmin=2*PI/(wmax*OMEGASUN)/DAY
Pmax=2*PI/(wmin*OMEGASUN)/DAY

for P in np.logspace(np.log10(Pmin),np.log10(Pmax),10):
    #P=np.ceil(P)
    if P>Pmax:break
    w=2*PI/(P*DAY)/OMEGASUN
    ax.axhline(w,xmin=0.98,xmax=1.00,color='k')
    ax.text(tmax,w,"%.1f"%P,transform=offSet(5,0),verticalalignment='center',horizontalalignment='left',fontsize=10)

ax.set_ylabel("$\Omega/\Omega_\odot$")
ax.set_xlabel(r"$\tau$ (Gyr)")
ax.grid(which='both')

saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/stellar-rotation.png',watermarkpos="outer")
