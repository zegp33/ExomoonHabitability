from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
star=loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.conf")+loadConf("objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.15,0.1,0.8,0.8])

ts=star.activity[:,0]
Ml=star.activity[:,7]

ax.plot(ts,Ml)

ax.text(4.56,MDOTSUN*YEAR/MSUN,r"$\odot$",
        horizontalalignment='center',verticalalignment='center',
        fontsize=20)

ax.set_xscale("log")
ax.set_yscale("log")

ax.set_title(star.title,position=(0.5,1.02),fontsize=12)
ax.set_xlim((TAU_ZAMS,star.tau_ms))

ax.set_ylabel(r"$\dot M$ ($M_\odot$/yr)")
ax.set_xlabel(r"$\tau$ (Gyr)")

ax.grid(which='both')

saveFig('objs/star-5d8ad29ace3e1bff3c56cb41cdebc894/stellar-massloss.png',watermarkpos="outer")
