from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
from BHM.BHMnum import *
bbox=dict(fc='w',ec='none')

star=loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.conf")+loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.data")

fig=plt.figure(figsize=(8,6))
ax=fig.add_axes([0.1,0.1,0.8,0.8])
bbox=dict(fc='w',ec='none')

#MAIN PLOT
ts,Ievo=interpMatrix(star.Ievo)

yplots=[Ievo[1](ts)]
ax.plot(ts,Ievo[1](ts),color='r',label='Convective Envelope')
if star.M>=MMIN_CONV:
   cond=Ievo[2](ts)>0
   ax.plot(ts[cond],np.log10(Ievo[2](ts[cond])),color='b',label='Radiative Core')
   yplots+=[Ievo[1](ts)]

#DECORATIONS
ax.set_xlabel(r"$\log\,\tau$ (Gyr)")
ax.set_ylabel(r"$\log\, I$ (kg m$^2$)")

ymin,ymean,ymax=minmeanmaxArrays(yplots)
ax.set_ylim((44,ymax))
ax.set_xlim((ts[0],ts[-1]))
ax.set_title(star.title,position=(0.5,1.02),fontsize=12)
ax.grid(which="both")
ax.legend(loc='lower right',prop=dict(size=11))

#MODEL WATERMARK
ax.text(0.5,0.95,"PARSEC:Z=0.0140,M=1.20",horizontalalignment="center",fontsize=10,color="k",alpha=0.3,transform=ax.transAxes,bbox=bbox)


saveFig('objs/star-2172f42df8a5a07098c43050098c388d/evol-moi.png',watermarkpos="outer")
