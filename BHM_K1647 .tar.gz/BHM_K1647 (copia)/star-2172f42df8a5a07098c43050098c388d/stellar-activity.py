from BHM import *
from BHM.BHMplot import *
from numpy import array

from BHM.BHMstars import *
star=loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.conf")+loadConf("objs/star-2172f42df8a5a07098c43050098c388d/"+"star.data")

Ni=4
fig=plt.figure(figsize=(8,6*(Ni-1)))
l=0.1;b=0.05;dh=0.02;h=(1.0-2*b-(Ni-1)*dh)/Ni;w=1.0-1.5*l

ax_R=fig.add_axes([l,b,w,h])
b+=h+dh
ax_f=fig.add_axes([l,b,w,h])
b+=h+dh
ax_B=fig.add_axes([l,b,w,h])
b+=h+dh
ax_RX=fig.add_axes([l,b,w,h])

ts=star.activity[:,0]
f=star.activity[:,2]
B=star.activity[:,4]
R=star.activity[:,6]
RX=star.activity[:,11]
axs=[ax_R,ax_f,ax_B,ax_RX]

args=dict(color='k')

ax_R.plot(ts,R,**args)
ax_R.set_ylabel("Rossby Number")
ax_R.axhline(0.13,linestyle='--',linewidth=2,color='r',label='Saturation Level')

ax_f.plot(ts,f,**args)
ax_f.set_ylabel("Filling factor, $f_\star$")

ax_B.plot(ts,B,**args)
ax_B.set_ylabel("Photospheric field (not averaged), $B_\star$ (G)")

ax_RX.plot(ts,RX,**args)
ax_RX.set_ylabel(r"$R_{\rm X}$")

ax_R.legend(loc='best',prop=dict(size=12))
for ax in axs:
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim((TAU_ZAMS,star.tau_ms))
    ax.grid(which='both')

ax_B.set_yscale("linear")

axs[-1].set_title(star.title,position=(0.5,1.02),fontsize=12)
axs[0].set_xlabel(r"$\tau$ (Gyr)")

for ax in axs[1:]:
    ax.set_xticklabels([])


saveFig('objs/star-2172f42df8a5a07098c43050098c388d/stellar-activity.png',watermarkpos="outer")
